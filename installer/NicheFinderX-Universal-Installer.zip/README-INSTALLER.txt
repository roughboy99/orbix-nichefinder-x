============================================================
  ORBIX NICHEFINDER X v1.03 — Windows Installer Package
  Orbix Automation Solutions | getorbix.com
  (610) ORBIX AI — (610) 672-4924
============================================================

CONTENTS OF THIS PACKAGE
--------------------------
  INSTALL.bat               — Double-click to run installer
  NicheFinderX-Setup.ps1    — PowerShell installer script (called by INSTALL.bat)
  README-INSTALLER.txt      — This file

HOW TO INSTALL
--------------------------
1. Make sure INSTALL.bat and NicheFinderX-Setup.ps1 are in the SAME folder
2. Double-click INSTALL.bat
3. Follow the on-screen prompts
4. The installer will:
   - Check for Node.js 18+ (and install it automatically if missing)
   - Create the NicheFinderX app folder (default: C:\Users\YOU\NicheFinderX)
   - Install all dependencies via npm
   - Create a Desktop shortcut: "NicheFinder X"
   - Create a Start Menu shortcut: Orbix > NicheFinder X
5. Launch via the Desktop shortcut or Start Menu

REQUIREMENTS
--------------------------
  - Windows 10 or Windows 11
  - Internet connection (for Node.js install and API calls)
  - Node.js 18+ (auto-installed if missing)
  - A TwitterAPI.io API key — get one at:
    https://twitterapi.io?ref=roughboy666

AFTER INSTALL
--------------------------
  The app runs at: http://localhost:5173
  Launch it anytime via the Desktop shortcut.
  The shortcut starts a local server and opens your browser.
  Press Ctrl+C in the terminal window to stop the server.

AFFILIATE DISCLOSURE
--------------------------
  Links to TwitterAPI.io in this application are affiliate links.
  Orbix Automation Solutions may earn a commission if you sign up.
  This does not add any cost to you.

SUPPORT
--------------------------
  getorbix.com | (610) ORBIX AI — (610) 672-4924

============================================================
